
const express=require("express")
const stripe=require("stripe")("sk_test_REPLACE_WITH_SECRET_KEY")
const nodemailer=require("nodemailer")

const app=express()

app.use(express.static("."))
app.use(express.urlencoded({extended:true}))
app.use(express.json())

const transporter=nodemailer.createTransport({
host:"smtp.gmail.com",
port:587,
secure:false,
auth:{
user:"YOUR_EMAIL@gmail.com",
pass:"YOUR_APP_PASSWORD"
}
})

app.post("/send-enquiry",async(req,res)=>{

const {name,email,company,service,message}=req.body

await transporter.sendMail({
from:email,
to:"YOUR_EMAIL@gmail.com",
subject:"New Website Enquiry",
text:`Name: ${name}
Email: ${email}
Company: ${company}
Service: ${service}

Message:
${message}`
})

res.send("<h1>Thank you. Your enquiry has been sent.</h1>")

})

app.listen(3000,()=>console.log("Server running"))
